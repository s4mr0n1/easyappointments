INSERT INTO ea_settings (name, value) VALUES
    ('google_analytics_code', ''),
    ('customer_notifications', '1'),
    ('date_format', 'DMY'),
    ('require_captcha', '1');
