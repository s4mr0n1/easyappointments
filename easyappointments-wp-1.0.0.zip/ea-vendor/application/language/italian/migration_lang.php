<?php

$lang['migration_none_found']			= "Nessun migration trovato.";
$lang['migration_not_found']			= "Questo migration non può essere trovato.";
$lang['migration_multiple_version']		= "Ci sono più migrations con lo stesso numero di versione: %d.";
$lang['migration_class_doesnt_exist']	= "La migration class \"%s\" non può essere trovata.";
$lang['migration_missing_up_method']	= "La migration class \"%s\" non dispone del metodo 'up'.";
$lang['migration_missing_down_method']	= "La migration class \"%s\" non dispone del metodo 'down'.";
$lang['migration_invalid_filename']		= "Il migration \"%s\" ha un filename non valido.";


/* End of file migration_lang.php */
/* Location: ./system/language/italian/migration_lang.php */
